package bank_ATM_system;

import javax.swing.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class GemailSender {
    String pin;
    public void savetoFile(String content){
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("save as");
        int userSelection = fileChooser.showSaveDialog(null);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            // Get the file selected by the user
            File fileToSave = fileChooser.getSelectedFile();

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                writer.write(content); // Write the content of JTextArea to the file
                JOptionPane.showMessageDialog(null, "File saved successfully to " + fileToSave.getAbsolutePath());
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "An error occurred while saving the file.");
            }
        }
    }
    GemailSender(String pin, JTextArea ta){
        this.pin = pin;

        String content = ta.getText();
        savetoFile(content);

    }
}
