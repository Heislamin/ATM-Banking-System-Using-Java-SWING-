package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Random;

public class register extends JFrame implements ActionListener {
    JButton next;
    JRadioButton r1,r2,r3,rmar,runmar;
    JTextField TextName,textFname,textEmail,textMS,textAdd,textcity,textzip,textstate;
    Random ran = new Random();
    JDateChooser dateChooser;
    long first4 = (ran.nextLong() % 9000L) +1000L;
    String first = " "+Math.abs(first4);
    register(){
        super ("APPLICATION FORM");

        setTitle("Banking System - Account Creation");
        setSize(870, 800);  // Set window size to 1000x900
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // Using absolute layout for custom positioning

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(25, 10, 100, 100);
        add(image);

        JLabel label1 = new JLabel("APPLICATION FORM NO. "+first);
        label1.setBounds(190,20,600,40);
        label1.setFont(new Font("Rale way",Font.BOLD,38));
        add(label1);

        JLabel label2 = new JLabel("Page 1");
        label2.setBounds(300,90,600,30);
        label2.setFont(new Font("Rale way",Font.BOLD,22));
        add(label2);

        JLabel label3 = new JLabel("Personal Details");
        label3.setBounds(300,120,600,30);
        label3.setFont(new Font("Rale way",Font.BOLD,22));
        add(label3);

        JLabel labelName = new JLabel("Name ");
        labelName.setBounds(100,190,100,30);
        labelName.setFont(new Font("Rale way",Font.BOLD,20));
        add(labelName);

        TextName = new JTextField();
        TextName.setFont(new Font("Rale way",Font.BOLD,20));
        TextName.setBounds(300,190,400,30);
        add(TextName);

        JLabel labelfName = new JLabel("Father's Name ");
        labelfName.setBounds(100,240,300,30);
        labelfName.setFont(new Font("Rale way",Font.BOLD,20));
        add(labelfName);

        textFname = new JTextField();
        textFname.setFont(new Font("Rale way",Font.BOLD,20));
        textFname.setBounds(300,240,400,30);
        add(textFname);

        JLabel dob = new JLabel("Date of Birth ");
        dob.setBounds(100,340,200,30);
        dob.setFont(new Font("Rale way",Font.BOLD,20));
        add(dob);

        dateChooser = new JDateChooser();
        dateChooser.setForeground(new Color(105,105,105, 0));
        dateChooser.setBounds(300,340,400,30);
        add(dateChooser);

        JLabel labelG = new JLabel("Gender");
        labelG.setFont(new Font("Rale way",Font.BOLD,20));
        labelG.setBounds(100,290,200,30);
        add(labelG);

        r1 = new JRadioButton("Male");
        r1.setFont(new Font("Rale way",Font.BOLD,14));
        r1.setBounds(300,290,80,30);
        add(r1);

        r2 = new JRadioButton("Female");
        r2.setFont(new Font("Rale way",Font.BOLD,14));
        r2.setBounds(400,290,80,30);
        add(r2);

        r3 = new JRadioButton("Other");
        r3.setFont(new Font("Rale way",Font.BOLD,14));
        r3.setBounds(500,290,80,30);
        add(r3);

        ButtonGroup btngrp = new ButtonGroup();
        btngrp.add(r1);
        btngrp.add(r2);
        btngrp.add(r3);

        JLabel labelemail = new JLabel("Email ");
        labelemail.setFont(new Font("Rale way",Font.BOLD,20));
        labelemail.setBounds(100,390,200,30);
        add(labelemail);

        textEmail = new JTextField();
        textEmail.setFont(new Font("Rale way",Font.BOLD,20));
        textEmail.setBounds(300,390,400,30);
        add(textEmail);

        JLabel labelms = new JLabel("Marital Status ");
        labelms.setFont(new Font("Rale way",Font.BOLD,20));
        labelms.setBounds(100,440,400,30);
        add(labelms);

        rmar = new JRadioButton("Married");
        rmar.setFont(new Font("Rale way",Font.BOLD,14));
        rmar.setBounds(300,440,80,30);
        add(rmar);

        runmar = new JRadioButton("Unmarried");
        runmar.setFont(new Font("Rale way",Font.BOLD,14));
        runmar.setBounds(400,440,100,30);
        add(runmar);

        ButtonGroup butngrp = new ButtonGroup();
        butngrp.add(rmar);
        butngrp.add(runmar);

        JLabel labelAdd = new JLabel("Address ");
        labelAdd.setFont(new Font("Rale way",Font.BOLD,20));
        labelAdd.setBounds(100,490,400,30);
        add(labelAdd);

        textAdd = new JTextField();
        textAdd.setFont(new Font("Rale way",Font.BOLD,20));
        textAdd.setBounds(300,490,400,30);
        add(textAdd);

        JLabel labelcity = new JLabel("City ");
        labelcity.setFont(new Font("Rale way",Font.BOLD,20));
        labelcity.setBounds(100,540,400,30);
        add(labelcity);

        textcity = new JTextField();
        textcity.setFont(new Font("Rale way",Font.BOLD,20));
        textcity.setBounds(300,540,400,30);
        add(textcity);

        JLabel labelzip = new JLabel("Zip Code ");
        labelzip.setFont(new Font("Rale way",Font.BOLD,20));
        labelzip.setBounds(100,590,400,30);
        add(labelzip);

        textzip = new JTextField();
        textzip.setFont(new Font("Rale way",Font.BOLD,20));
        textzip.setBounds(300,590,400,30);
        add(textzip);

        JLabel labelstate = new JLabel("State ");
        labelstate.setFont(new Font("Rale way",Font.BOLD,20));
        labelstate.setBounds(100,640,400,30);
        add(labelstate);

        textstate = new JTextField();
        textstate.setFont(new Font("Rale way",Font.BOLD,20));
        textstate.setBounds(300,640,400,30);
        add(textstate);

        next = new JButton("Next");
        next.setFont(new Font("Rale way",Font.BOLD,14));
        next.setBackground(Color.BLACK);
        next.setForeground(Color.white);
        next.setBounds(620,710,80,30);
        next.addActionListener(this);
        add(next);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/bank.png")));
        setIconImage(logo.getImage());


        setLayout(null);
        getContentPane().setBackground(new Color(207, 207, 207));
        setLocation(360,10);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String frmno = first;
        String name = TextName.getText();
        String fname = textFname.getText();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = null;
        if (r1.isSelected()){
            gender = "Male";
        } else if (r2.isSelected()) {
            gender = "Female";
        } else {
            gender = "other";
        }
        String email = textEmail.getText();
        String marital = null;
        if (rmar.isSelected()){
            marital = "Married";
        } else {
            marital = "Unmarried";
        }
        String address = textAdd.getText();
        String city = textcity.getText();
        String zipcode = textzip.getText();
        String state = textstate.getText();

        System.out.println(frmno);
        System.out.println(name);
        System.out.println(fname);
        System.out.println(dob);
        System.out.println(gender);
        System.out.println(email);
        System.out.println(marital);
        System.out.println(address);
        System.out.println(city);
        System.out.println(zipcode);
        System.out.println(state);

        try{
            if (name.isEmpty() || fname.isEmpty() || dob.isEmpty() || email.isEmpty() || address.isEmpty() || city.isEmpty() || zipcode.isEmpty() || state.isEmpty()){
                JOptionPane.showMessageDialog(null,"Fill all the Fields");
            }else {
                Conn conn7 = new Conn();
                conn7.ConnectMain();
                conn7.insert_into_register(frmno,name,fname,dob,gender,email,marital,address,city,zipcode,state);
                new register2(frmno);
                setVisible(false);
            }
        }catch (Exception E){
            E.printStackTrace();
        }

    }

    public static void main(String[] args) {
        new register();
    }
}
