package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.Objects;


public class login extends JFrame implements ActionListener {
    JLabel label1, label2, label3;
    JTextField textField2;
    JPasswordField passField3;
    JButton Btn1, Btn2, Btn3;
    String pin;

    login() {
        super("ATM Management System");

        // Bank Logo
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(370, 10, 100, 100);
        add(image);

        // bottom icon
        ImageIcon ii1 = new ImageIcon(ClassLoader.getSystemResource("icon/card.png"));
        Image ii2 = ii1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon ii3 = new ImageIcon(ii2);
        JLabel iimage = new JLabel(ii3);
        iimage.setBounds(660, 350, 100, 100);
        add(iimage);

        label1 = new JLabel("L&M's Bank Services");
        label1.setForeground(Color.white);
        label1.setFont(new Font("AvantGarde", Font.BOLD, 38));
        label1.setBounds(255, 127, 450, 40);
        add(label1);

        label2 = new JLabel("Card No: ");
        label2.setForeground(Color.white);
        label2.setFont(new Font("Railway", Font.BOLD, 28));
        label2.setBounds(150, 195, 375, 30);
        add(label2);

        textField2 = new JTextField(15);
        textField2.setBounds(325, 195, 230, 30);
        textField2.setFont(new Font("Arial", Font.BOLD, 14));
        add(textField2);
        AbstractDocument document1 = (AbstractDocument) textField2.getDocument();
        document1.setDocumentFilter(new NumericDocumentFilter());


        label3 = new JLabel("PIN: ");
        label3.setForeground(Color.white);
        label3.setFont(new Font("Railway", Font.BOLD, 28));
        label3.setBounds(150, 255, 375, 30);
        add(label3);

        passField3 = new JPasswordField(15);
        passField3.setBounds(325, 255, 230, 30);
        passField3.setFont(new Font("Arial", Font.BOLD, 14));
        add(passField3);
        AbstractDocument document2 = (AbstractDocument) passField3.getDocument();
        document2.setDocumentFilter(new NumericDocumentFilter());

        Btn1 = new JButton("LOG IN");
        Btn1.setFont(new Font("Arial", Font.BOLD, 14));
        Btn1.setForeground(Color.WHITE);
        Btn1.setBackground(Color.BLACK);
        Btn1.setBounds(457, 310, 100, 30);
        Btn1.addActionListener(this);
        add(Btn1);

        Btn2 = new JButton("RESET");
        Btn2.setFont(new Font("Arial", Font.BOLD, 14));
        Btn2.setForeground(Color.WHITE);
        Btn2.setBackground(Color.BLACK);
        Btn2.setBounds(323, 310, 100, 30);
        Btn2.addActionListener(this);
        add(Btn2);

        Btn3 = new JButton("REGISTER");
        Btn3.setFont(new Font("Arial", Font.BOLD, 14));
        Btn3.setForeground(Color.WHITE);
        Btn3.setBackground(Color.BLACK);
        Btn3.setBounds(323, 365, 235, 30);
        Btn3.addActionListener(this); // Corrected this line
        add(Btn3);

        // Background Image
        ImageIcon iii1 = new ImageIcon(ClassLoader.getSystemResource("icon/bg.jpg"));
        Image iii2 = iii1.getImage().getScaledInstance(850, 480, Image.SCALE_DEFAULT);
        ImageIcon iii3 = new ImageIcon(iii2);
        JLabel iiimage = new JLabel(iii3);
        iiimage.setBounds(0, 0, 850, 480);
        add(iiimage);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/bank.png")));
        setIconImage(logo.getImage());

        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(850, 480);
        setLocation(300, 200);
        setVisible(true);
    }

    public String PIN_hashing(String pin) throws NoSuchAlgorithmException {
        MessageDigest msgDigest = MessageDigest.getInstance("MD5");
        msgDigest.update(pin.getBytes(StandardCharsets.UTF_8));
        byte[] result = msgDigest.digest();

        StringBuilder sb = new StringBuilder();

        for (byte b : result){
            sb.append(String.format("%02x",b));
        }
        return sb.toString();
    }

    public boolean verifyPIN(String inputPIN, String storedHash) {
        try {
            String hashedInput = PIN_hashing(inputPIN);
            return hashedInput.equals(storedHash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String card_no = textField2.getText();
        this.pin = new String(passField3.getPassword());
        String PIN = new String(passField3.getPassword());

        try {
            if (e.getSource() == Btn1) {
                if (textField2.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please Fill all the Fields");
                } else {
                    Conn con1 = new Conn();
                    con1.ConnectMain();
                    String HashedPIN = PIN_hashing(pin);
                    this.pin = HashedPIN;
                    //pin = hash pin
                    int row_count = con1.loginCheck(card_no, this.pin);
//                    int row_count = con1.loginCheck(card_no,PIN);
                    if (row_count == 1){
                        JOptionPane.showMessageDialog(null, "Login Success press OK to Continue");
                        Locale currentLocale = Locale.ENGLISH;
//                        new MainScreen(HashedPIN,currentLocale);
                        new MainScreen(this.pin,currentLocale);
                        setVisible(false);
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Login Failed Please Enter Right Credentials");
                        textField2.setText("");
                        passField3.setText("");
                    }
                }
            } else if (e.getSource() == Btn2) {
                textField2.setText("");
                passField3.setText("");
            } else if (e.getSource() == Btn3) {
                new register();
                setVisible(false);
            }
        } catch (Exception E) {
            E.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new login();
    }
}


// Custom DocumentFilter to allow only numeric input

