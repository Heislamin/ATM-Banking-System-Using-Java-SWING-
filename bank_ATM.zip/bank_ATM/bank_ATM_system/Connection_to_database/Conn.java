package bank_ATM_system.Connection_to_database;

import javax.swing.*;
import java.sql.*;
import java.util.Date;

public class Conn {
    public Connection con;
    public Statement statement;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    public void ConnectMain() {
        try {
            this.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_system", "root", "Capalot001@");

            String databaseName = "bank_system";
            String userName = "root";
            String password = "Capalot001@";


            System.out.println("Connection Successful");
            System.out.println(this.con);


            this.statement = this.con.createStatement();
            System.out.println(this.statement);

//            JOptionPane.showMessageDialog(null,"query executed successfully");
        } catch (Exception E) {
            E.printStackTrace();
        }
    }

    // No Requirement as of Now
    public void loginInsert(String cardno, String pin) throws SQLException {
        this.ConnectMain();
        PreparedStatement q1 = this.con.prepareStatement("INSERT INTO `login` VALUES ('" + cardno + "','" + pin + "')");
        int status = q1.executeUpdate();
        if (status > 0) {
            System.out.println("Data inserted Successfully");
        } else {
            System.out.println("Insertion Failed!");
        }
    }

    public int loginCheck(String card_no, String pin) throws SQLException {
        this.ConnectMain();
        String q1 = ("SELECT COUNT(*) AS count FROM login WHERE cardNo='" + card_no + "' AND pin='" + pin + "' " );
        ResultSet resultSet = this.statement.executeQuery(q1);

        int count = 0;
        if (resultSet.next()) {
            count = resultSet.getInt("count");
        }
        System.out.println(count);
        return count;
    }

    public void depositInsert(String pin, String amount, Date dateTime) throws SQLException {
        this.ConnectMain();
        this.preparedStatement = this.con.prepareStatement("INSERT INTO `deposit` (pin,date,type,amount) VALUES ('" + pin + "', '" + dateTime + "', '" + "DEPOSIT" + "', '" + amount + "')");
        int status = preparedStatement.executeUpdate();
        if (status > 0) {
            System.out.println("deposit Data inserted Successfully");

        } else {
            System.out.println("Insertion Failed!");
        }

        String select1 = "SELECT * FROM totaldeposits WHERE pin = '" + pin + "' AND type = 'DEPOSIT'";
        this.preparedStatement = this.con.prepareStatement(select1);
        preparedStatement.executeQuery(select1);

        int rows = 0;
        resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            rows += 1;
        }
        if (rows >= 1) {
            String update = "UPDATE `totaldeposits` SET `amount` = (SELECT SUM(amount) FROM deposit WHERE pin = '" + pin + "' AND type = 'DEPOSIT') WHERE pin = '" + pin + "'";
            this.preparedStatement = this.con.prepareStatement(update);
            preparedStatement.executeUpdate();
        } else {
//            String insert = "INSERT INTO totaldeposits (pin, type, amount)\n" +
//                    "SELECT pin, type, amount\n" +
//                    "FROM deposit\n" +
//                    "WHERE pin = '" + pin + "' AND type = 'DEPOSIT';\n";
            String insert = "INSERT INTO totaldeposits (pin, type, amount) VALUES ('"+pin+"','"+"DEPOSIT"+"','"+amount+"')";
            this.preparedStatement = this.con.prepareStatement(insert);
            preparedStatement.executeUpdate(insert);

            String insertWithdraw = "INSERT INTO `totalwithdraws` (pin, type, amount) VALUES ('" + pin + "', '" + "WITHDRAWAL" + "', '" + "0.0" + "')";
            this.preparedStatement = this.con.prepareStatement(insertWithdraw);
            preparedStatement.executeUpdate(insertWithdraw);
        }
    }

    public void withdraw(String pin, String amount, Date date) throws SQLException {
        this.ConnectMain();
        PreparedStatement p1 = this.con.prepareStatement("INSERT INTO `deposit`(pin,date,type,amount) VALUES ('" + pin + "', '" + date + "', 'WITHDRAWAL', '" + amount + "')");
        int status = p1.executeUpdate();

        if (status > 0) {
            System.out.println("Withdrawal Data inserted Successfully");
        } else {
            System.out.println("Insertion Failed!");
        }

        String select1 = "SELECT * FROM totalwithdraws WHERE pin = '" + pin + "' AND type = 'WITHDRAWAL'";
        this.preparedStatement = this.con.prepareStatement(select1);
        preparedStatement.executeQuery(select1);

        int rows = 0;
        resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            rows += 1;
        }
        if (rows >= 1) {
            String update = "UPDATE `totalwithdraws` SET `amount` = (SELECT SUM(amount) FROM deposit WHERE pin = '" + pin + "' AND type = 'WITHDRAWAL') WHERE pin = '" + pin + "'";
            this.preparedStatement = this.con.prepareStatement(update);
            preparedStatement.executeUpdate();
        } else {
            String insertWithdraw = "INSERT INTO `totalwithdraws` (pin, type, amount) VALUES ('" + pin + "', '" + "WITHDRAWAL" + "', '" + "0.0" + "')";
            this.preparedStatement = this.con.prepareStatement(insertWithdraw);
            preparedStatement.executeUpdate();
        }
    }

    public void insertIntoNetbalance(String pin) throws SQLException {
        this.ConnectMain();
        PreparedStatement q1 = this.con.prepareStatement("SELECT (amount) FROM totaldeposits where pin = '" + pin + "'");
        ResultSet rs_deposit = q1.executeQuery();
        String deposit_amt = "";
        while (rs_deposit.next()) {
            deposit_amt = rs_deposit.getString("amount");
        }
        double Total_depositAMT = Double.parseDouble(deposit_amt);

        PreparedStatement q2 = this.con.prepareStatement("SELECT (amount) FROM totalwithdraws where pin = '" + pin + "'");
        ResultSet rs_withdraw = q2.executeQuery();
        String withdraw_amt = "";
        while (rs_withdraw.next()) {
            withdraw_amt = rs_withdraw.getString("amount");
        }

        double Total_withdrawAMT = Double.parseDouble(withdraw_amt);


        double netBalance = Total_depositAMT - Total_withdrawAMT;
        String netBal = Double.toString(netBalance);

        String select = "SELECT * FROM netbalance WHERE pin = '" + pin + "'";
        this.preparedStatement = this.con.prepareStatement(select);
        preparedStatement.executeQuery(select);

        int rows = 0;
        resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            rows += 1;
        }
        if (rows == 1) {
            String update = "UPDATE `netbalance` SET `amount` = '" + netBal + "' WHERE pin = '" + pin + "'";
            this.preparedStatement = this.con.prepareStatement(update);
            preparedStatement.executeUpdate();
        } else if (rows < 1) {
            PreparedStatement q3 = this.con.prepareStatement("INSERT INTO `netbalance` (pin,amount) VALUES ('" + pin + "','" + netBal + "')");
            int status = q3.executeUpdate();
            if (status > 0) {
                System.out.println("net balance Data inserted Successfully");
            } else {
                System.out.println("Insertion Failed!");
            }
        }

    }

    public String check_Bal(String pin) throws SQLException {
        this.ConnectMain();
        this.insertIntoNetbalance(pin);
        PreparedStatement q1 = this.con.prepareStatement("SELECT amount FROM netbalance where pin = '" + pin + "'");
        ResultSet rs_netbal = q1.executeQuery();

        String net_amt = "";
        while (rs_netbal.next()) {
            net_amt = rs_netbal.getString("amount");
        }
        return net_amt;
    }

    public void fastCashWithdrawal(String pin, Date date, String amount) throws SQLException {
        this.ConnectMain();
        PreparedStatement q1 = this.con.prepareStatement("INSERT INTO `deposit` (pin,date,type,amount) VALUES ('" + pin + "', '" + date + "', 'WITHDRAWAL', '" + amount + "')");
        q1.executeUpdate();

        String select1 = "SELECT * FROM totalwithdraws WHERE pin = '" + pin + "' AND type = 'WITHDRAWAL'";
        this.preparedStatement = this.con.prepareStatement(select1);
        preparedStatement.executeQuery(select1);
        int rows = 0;
        resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            rows += 1;
        }
        if (rows == 1) {
            String update = "UPDATE `totalwithdraws` SET `amount` = (SELECT SUM(amount) FROM deposit WHERE pin = '" + pin + "' AND type = 'WITHDRAWAL') WHERE pin = '" + pin + "'";
            this.preparedStatement = this.con.prepareStatement(update);
            preparedStatement.executeUpdate();
        } else if (rows < 1) {
            String insert = "INSERT INTO totalwithdraws (pin, type, amount)\n" +
                    "SELECT pin, type, amount\n" +
                    "FROM deposit\n" +
                    "WHERE pin = '" + pin + "' AND type = 'WITHDRAWAL';\n";
            this.preparedStatement = this.con.prepareStatement(insert);
            preparedStatement.executeUpdate();
        }
    }

    public void MiniStatement(String pin, JTextArea ta) throws SQLException {
        String netbl = check_Bal(pin);
        String select1 = "SELECT l.cardNo as cardno, dep.date as date, dep.type as type, dep.amount as amt " +
                "FROM login l, deposit dep " +
                "WHERE l.pin = dep.pin AND l.pin = '"+pin+"'";

        this.preparedStatement = this.con.prepareStatement(select1);
        ResultSet rs = preparedStatement.executeQuery();

// Use a StringBuilder to accumulate results
        StringBuilder l1Content = new StringBuilder();
        boolean firstRecord = true; // Flag to manage the first record display

        while (rs.next()) { // Loop through all records
            if (firstRecord) {
                // Set card number, masking it appropriately for the first record
                ta.append("Card Number: " + rs.getString("cardno").substring(0, 4) + "XXXXXXXX" + rs.getString("cardno").substring(12) + "\n\n\n");
                firstRecord = false; // Change flag after first record
            }
            // Append the current record's details to the StringBuilder
            l1Content.append(rs.getString("date")).append("   ")
                    .append(rs.getString("type")).append("   ")
                    .append(rs.getString("amt")).append("\n\n");
        }

// Set the accumulated text to l1
        ta.append( l1Content.toString());

// Query for the second select statement
//        String select2 = "SELECT amount FROM netbalance WHERE pin = ?";
//        this.preparedStatement = this.con.prepareStatement(select2);
//        preparedStatement.setString(1, pin);
//        ResultSet rs2 = preparedStatement.executeQuery();
//
//        if (rs2.next()) { // Ensure there's at least one record
//            ta.append("Your Total Balance: " + rs2.getString("amount"));
//        }
        ta.append("Your Total Balance: " + netbl);
    }

    public void Pin_Update(String pin,String HashedPin) throws SQLException{
        this.ConnectMain();
        PreparedStatement q1 = this.con.prepareStatement("UPDATE login SET pin = '"+HashedPin+"' WHERE pin = '"+pin+"'");
        q1.executeUpdate();
        q1 = this.con.prepareStatement("UPDATE deposit SET pin = '"+HashedPin+"' WHERE pin = '"+pin+"'");
        q1.executeUpdate();
        q1 = this.con.prepareStatement("UPDATE netbalance SET pin = '"+HashedPin+"' WHERE pin = '"+pin+"'");
        q1.executeUpdate();
        q1 = this.con.prepareStatement("UPDATE totaldeposits SET pin = '"+HashedPin+"' WHERE pin = '"+pin+"'");
        q1.executeUpdate();
        q1 = this.con.prepareStatement("UPDATE totalwithdraws SET pin = '"+HashedPin+"' WHERE pin = '"+pin+"'");
        q1.executeUpdate();
        System.out.println(q1);
    }

    public void insert_into_register(String frmno,String name,String fname,String dob,String gender,String email,String marital,String address,String city,String zipcode,String state) throws SQLException {
        this.preparedStatement = this.con.prepareStatement(
                "INSERT INTO `signup` VALUES " +
                        "('" + frmno + "', '" + name + "', '" + fname + "', '" + dob + "', '" + gender + "','" + email + "','" + marital + "','" + address + "','" + city + "','" + zipcode + "','" + state + "')"
        );
        int status = preparedStatement.executeUpdate();
        if (status > 0) {
            System.out.println("Signup Data inserted Successfully");

        } else {
            System.out.println("Insertion Failed!");
        }

    }

    public void insert_into_register2(String formNo,String rel,String cat,String income,String edu,String occ,String PAN,String aadhar,String scitizen,String exaccount) throws SQLException {
        this.preparedStatement = this.con.prepareStatement(
                "INSERT INTO `signup2` VALUES " +
                        "('" + formNo + "', '" + rel + "', '" + cat + "', '" + income + "', '" + edu + "','" + occ + "','" + PAN + "','" + aadhar + "','" + scitizen + "','" + exaccount + "')"
        );
        int status = preparedStatement.executeUpdate();
        if (status > 0) {
            System.out.println("Signup2 Data inserted Successfully");

        } else {
            System.out.println("Insertion Failed!");
        }
    }

    public void insert_into_register3(String formNo,String acType,String cardNO,String PIN,String fac) throws SQLException {
        this.preparedStatement = this.con.prepareStatement(
                "INSERT INTO `signup3` VALUES " +
                        "('" + formNo + "', '" + acType + "', '" + cardNO + "', '" + PIN + "', '" + fac + "')"
        );
        int status = preparedStatement.executeUpdate();
        if (status > 0) {
            System.out.println("Signup3 Data inserted Successfully");

        } else {
            System.out.println("Insertion Failed!");
        }
    }

}