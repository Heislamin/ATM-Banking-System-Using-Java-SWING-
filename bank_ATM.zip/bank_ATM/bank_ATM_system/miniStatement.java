package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class miniStatement extends JFrame implements ActionListener {
    String pin;
    JButton btn,btn2;
    JFrame miniframe;
    JTextArea ta;
    miniStatement(String pin){
        this.pin = pin;

        miniframe = new JFrame("L&M's ATM services - MiniStatement");
        miniframe.setBounds(20,100,400,400);
        miniframe.setSize(400,750);
        miniframe.setLocation(20,20);
        setLayout(null);
        miniframe.setLayout(new FlowLayout());

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/Statement.png")));
        miniframe.setIconImage(logo.getImage());

        ta = new JTextArea(40,35);
        ta.setEditable(false);
        miniframe.add(ta);
        miniframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        miniframe.setVisible(true);

        JScrollPane sp = new JScrollPane(ta,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        miniframe.add(sp);

        btn = new JButton("Exit");
        btn.addActionListener(this);
        btn.setBackground(Color.BLACK);
        btn.setForeground(Color.white);
        miniframe.add(btn);

        btn2 = new JButton("Download");
        btn2.addActionListener(this);
        btn2.setBackground(Color.BLACK);
        btn2.setForeground(Color.WHITE);
        miniframe.add(btn2);


        try{
            Conn con6 = new Conn();
            con6.ConnectMain();
            con6.MiniStatement(this.pin,ta);

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btn){
            miniframe.setVisible(false);
        } else if (e.getSource() == btn2) {
            new GemailSender(this.pin,ta);
            miniframe.setVisible(false);
        }
    }

    public static void main(String[] args) {
        new miniStatement("");
    }
}
