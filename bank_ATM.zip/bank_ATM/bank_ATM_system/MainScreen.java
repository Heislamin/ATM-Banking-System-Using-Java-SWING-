package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;

public class MainScreen extends JFrame implements ActionListener {
    JButton b1,b2,b3,b4,b5,b6,b7;
    String pin,cardNo;
    private JComboBox<String> languageComboBox;
    JLabel label;
    MainScreen(String pin,Locale locale){

        this.pin = pin;
//        ResourceBundle messages = ResourceBundle.getBundle("messages", locale);

        ImageIcon bg = new ImageIcon(ClassLoader.getSystemResource("icon/atm2.png"));
        Image bg2 = bg.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon bg3 = new ImageIcon(bg2);
        JLabel l1 = new JLabel(bg3);
        l1.setBounds(-40,0,1550,830);
        add(l1);

        label = new JLabel("Please Select Your Transaction");
        label.setBounds(422,180,700,35);
        label.setForeground(Color.white);
        label.setFont(new Font("System",Font.BOLD,28));
        l1.add(label);

        b1 = new JButton("DEPOSIT");
        b1.setForeground(Color.white);
        b1.setBackground(new Color(65,125,128));
        b1.setBounds(410,270,155,35);
        b1.addActionListener(this);
        l1.add(b1);

        b2 = new JButton("CASH WITHDRAWAL");
        b2.setForeground(Color.white);
        b2.setBackground(new Color(65,125,128));
        b2.setBounds(693,270,155,35);
        b2.addActionListener(this);
        l1.add(b2);

        b3 = new JButton("FAST CASH");
        b3.setForeground(Color.white);
        b3.setBackground(new Color(65,125,128));
        b3.setBounds(410,318,155,35);
        b3.addActionListener(this);
        l1.add(b3);

        b4 = new JButton("MINI STATEMENT");
        b4.setForeground(Color.white);
        b4.setBackground(new Color(65,125,128));
        b4.setBounds(693,318,155,35);
        b4.addActionListener(this);
        l1.add(b4);

        b5 = new JButton("PIN CHANGE");
        b5.setForeground(Color.white);
        b5.setBackground(new Color(65,125,128));
        b5.setBounds(410,365,155,35);
        b5.addActionListener(this);
        l1.add(b5);

        // Initialize JComboBox with language options
        languageComboBox = new JComboBox<>(new String[]{"English", "Spanish", "French"});
        languageComboBox.setSelectedItem("English");
        languageComboBox.setForeground(Color.white);
        languageComboBox.setBackground(new Color(65,125,128));
        languageComboBox.setBounds(410,413,155,35);
        languageComboBox.addActionListener(this);
//        l1.add(languageComboBox);

        languageComboBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                label.setHorizontalAlignment(SwingConstants.CENTER); // Center align the text
                return label;
            }
        });

//        JLabel label2 = new JLabel(messages.getString("Please Select Your Transaction"));


        b6 = new JButton("BALANCE ENQUIRY");
        b6.setForeground(Color.white);
        b6.setBackground(new Color(65,125,128));
        b6.setBounds(693,365,155,35);
        b6.addActionListener(this);
        l1.add(b6);

        b7 = new JButton("EXIT");
        b7.setForeground(Color.white);
        b7.setBackground(new Color(65,125,128));
        b7.setBounds(693,413,155,35);
        b7.addActionListener(this);
        l1.add(b7);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/ATMlogo.png")));
        setIconImage(logo.getImage());

        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocation(0,0);
        setVisible(true);

    }



    @Override
    public void actionPerformed (ActionEvent e) {
        try{
            if (e.getSource() == b1){
                new Deposit(this.pin);
                setVisible(false);
            } else if (e.getSource() == b7) {
                System.exit(0);
            } else if (e.getSource() == b2) {
                new withdrawal(pin);
                setVisible(false);
            } else if (e.getSource() == b6) {
                new BalanceEnquiry(this.pin);
                setVisible(false);
            } else if (e.getSource() == b3) {
                new FastCash(this.pin);
                setVisible(false);
            } else if (e.getSource() == b4) {
                new miniStatement(this.pin);
            } else if (e.getSource() == b5) {
                new PIN(this.pin);
            } else {
                String selectedLanguage = (String) languageComboBox.getSelectedItem();
                Locale newLocale = switch (selectedLanguage) {
                    case "Spanish" -> new Locale("es", "ES");
                    case "French" -> new Locale("fr", "FR");
                    default -> Locale.ENGLISH;  // Default to English
                };
                // Update the UI with the new locale
                ResourceBundle newMessages = ResourceBundle.getBundle("messages", newLocale);
                label.setText(newMessages.getString("Please Select Your Transaction"));
                b1.setText(newMessages.getString("DEPOSIT"));
                b2.setText(newMessages.getString("CASH WITHDRAWAL"));
                b3.setText(newMessages.getString("FAST CASH"));
                b4.setText(newMessages.getString("MINI STATEMENT"));
                b6.setText(newMessages.getString("BALANCE ENQUIRY"));
                b7.setText(newMessages.getString("EXIT"));


            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Locale currentLocale = Locale.ENGLISH;
        new MainScreen("",currentLocale);
    }
}
