package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Objects;

public class BalanceEnquiry extends JFrame implements ActionListener {
    JLabel label1, label0;
    JButton b1;
    String pin;

    private void displayBalance(String pin) {
        Conn con4 = new Conn();
        con4.ConnectMain();
        try {
            String netBalance = con4.check_Bal(pin);
            label1.setText(" " + netBalance); // Set the balance text
            label1.revalidate(); // Revalidate to update the layout
            label1.repaint(); // Repaint the label
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    BalanceEnquiry(String pin){
        this.pin = pin;

        ImageIcon bg = new ImageIcon(ClassLoader.getSystemResource("icon/atm2.png"));
        Image bg2 = bg.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon bg3 = new ImageIcon(bg2);
        JLabel l1 = new JLabel(bg3);
        l1.setBounds(-40,0,1550,830);
        add(l1);

        label0 = new JLabel(("Your Current Balance is Rs. "));
        label0.setForeground(Color.white);
        label0.setFont(new Font("System",Font.BOLD,16));
        label0.setBounds(460,280,700,35);
        l1.add(label0);

        label1 = new JLabel();
        label1.setForeground(Color.white);
        label1.setFont(new Font("System",Font.BOLD,16));
        label1.setBounds(455,305,400,35);
        l1.add(label1);

        displayBalance(this.pin);

        b1 = new JButton("BACK");
        b1.setBounds(700,363,150,35);
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.white);
        b1.addActionListener(this);
        l1.add(b1);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/ATMlogo.png")));
        setIconImage(logo.getImage());

        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocation(0,0);
        setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == b1){
                setVisible(false);
                Locale currentLocale = Locale.ENGLISH;
                new MainScreen(this.pin,currentLocale);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    public static void main(String[] args) {
        BalanceEnquiry b = new BalanceEnquiry("");
    }
}
