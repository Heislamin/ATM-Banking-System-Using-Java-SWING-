package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class FastCash extends JFrame implements ActionListener {
    JButton b1,b2,b3,b4,b5,b6,b7;
    String pin;
    FastCash(String pin){
        this.pin = pin;

        ImageIcon bg = new ImageIcon(ClassLoader.getSystemResource("icon/atm2.png"));
        Image bg2 = bg.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon bg3 = new ImageIcon(bg2);
        JLabel l1 = new JLabel(bg3);
        l1.setBounds(-40,0,1550,830);
        add(l1);

        JLabel label = new JLabel("SELECT WITHDRAWAL AMOUNT");
        label.setBounds(445,180,700,35);
        label.setForeground(Color.white);
        label.setFont(new Font("System",Font.BOLD,23));
        l1.add(label);

        b1 = new JButton("Rs. 100");
        b1.setForeground(Color.white);
        b1.setBackground(new Color(65,125,128));
        b1.setBounds(410,270,155,35);
        b1.addActionListener(this);
        l1.add(b1);

        b2 = new JButton("Rs. 500");
        b2.setForeground(Color.white);
        b2.setBackground(new Color(65,125,128));
        b2.setBounds(693,270,155,35);
        b2.addActionListener(this);
        l1.add(b2);

        b3 = new JButton("Rs. 1000");
        b3.setForeground(Color.white);
        b3.setBackground(new Color(65,125,128));
        b3.setBounds(410,318,155,35);
        b3.addActionListener(this);
        l1.add(b3);

        b4 = new JButton("Rs. 2000");
        b4.setForeground(Color.white);
        b4.setBackground(new Color(65,125,128));
        b4.setBounds(693,318,155,35);
        b4.addActionListener(this);
        l1.add(b4);

        b5 = new JButton("Rs. 5000");
        b5.setForeground(Color.white);
        b5.setBackground(new Color(65,125,128));
        b5.setBounds(410,365,155,35);
        b5.addActionListener(this);
        l1.add(b5);

        b6 = new JButton("Rs. 10000");
        b6.setForeground(Color.white);
        b6.setBackground(new Color(65,125,128));
        b6.setBounds(693,365,155,35);
        b6.addActionListener(this);
        l1.add(b6);

        b7 = new JButton("EXIT");
        b7.setForeground(Color.white);
        b7.setBackground(new Color(65,125,128));
        b7.setBounds(693,413,155,35);
        b7.addActionListener(this);
        l1.add(b7);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/ATMlogo.png")));
        setIconImage(logo.getImage());

        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocation(0,0);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b7){
            setVisible(false);
            Locale currentLocale = Locale.ENGLISH;
            new MainScreen(this.pin,currentLocale);
        } else {
            String amount = ((JButton)e.getSource()).getText().substring(4);
            try{
                Date date = new Date(System.currentTimeMillis());
                Conn con5 = new Conn();
                con5.ConnectMain();
                String netBal = con5.check_Bal(this.pin);
                double netBalance = Double.parseDouble(netBal);
                if (netBalance > 10000.00){
                    JOptionPane.showMessageDialog(null,"Amount Exceeded Maximum Withdrawal");
                } else if (netBalance < Double.parseDouble(amount)){
                    JOptionPane.showMessageDialog(null,"Insufficient Balance");
                }else {
                    con5.fastCashWithdrawal(this.pin,date,amount);
                    JOptionPane.showMessageDialog(null,"Rs. "+amount+" Withdrawn Successfully");
                    setVisible(false);
                    Locale currentLocale = Locale.ENGLISH;
                    new MainScreen(pin,currentLocale);
                }

            }catch (Exception E){
                E.printStackTrace();
            }

        }
    }

    public static void main(String[] args) {
        new FastCash("");
    }
}
