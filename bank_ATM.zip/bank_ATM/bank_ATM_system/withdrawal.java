package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;
import com.mysql.cj.protocol.Resultset;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class withdrawal extends JFrame implements ActionListener {

    String pin;

    JTextField textField;

    JButton b1,b2;
    withdrawal(String pin){
        this.pin = pin;

        ImageIcon bg = new ImageIcon(ClassLoader.getSystemResource("icon/atm2.png"));
        Image bg2 = bg.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon bg3 = new ImageIcon(bg2);
        JLabel l1 = new JLabel(bg3);
        l1.setBounds(-40,0,1550,830);
        add(l1);

        JLabel label0 = new JLabel(("MAXIMUM WITHDRAWAL IS RS.10000.00"));
        label0.setForeground(Color.white);
        label0.setFont(new Font("System",Font.BOLD,16));
        label0.setBounds(460,180,700,35);
        l1.add(label0);

        JLabel label1 = new JLabel(("PLEASE ENTER YOUR AMOUNT"));
        label1.setForeground(Color.white);
        label1.setFont(new Font("System",Font.BOLD,16));
        label1.setBounds(460,220,400,35);
        l1.add(label1);

        textField = new JTextField();
        textField.setBackground(new Color(65,125,128));
        textField.setForeground(Color.white);
        textField.setBounds(460,265,320,25);
        textField.setFont(new Font("Railway",Font.BOLD,22));
        l1.add(textField);
        AbstractDocument document1 = (AbstractDocument) textField.getDocument();
        document1.setDocumentFilter(new DoubleDocumentFilter());

        b1 = new JButton("WITHDRAW");
        b1.setBounds(700,363,150,35);
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.white);
        b1.addActionListener(this);
        l1.add(b1);

        b2 = new JButton("BACK");
        b2.setBounds(700,409,150,35);
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.white);
        b2.addActionListener(this);
        l1.add(b2);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/ATMlogo.png")));
        setIconImage(logo.getImage());

        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocation(0,0);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try{
            if (e.getSource() == b1){
                String amt = textField.getText();
                if (amt.isEmpty()){
                    JOptionPane.showMessageDialog(null,"Please Enter the Amount you want to Withdraw");
                }
                else {
                    Date date = new Date(System.currentTimeMillis());
                    Conn con3 = new Conn();
                    con3.ConnectMain();
                    String netBal = con3.check_Bal(this.pin);
                    double netBalance = Double.parseDouble(netBal);
                    System.out.println(netBalance);
                    if (Double.parseDouble(amt) > 10000.00){
                        JOptionPane.showMessageDialog(null,"Amount Exceeded Maximum Withdrawal");
                    } else if (netBalance < Double.parseDouble(amt)){
                        JOptionPane.showMessageDialog(null,"Insufficient Balance");
                    }
                    else {
                        con3.withdraw(this.pin,amt,date);
                        JOptionPane.showMessageDialog(null,"Amount Withdrawn Successfully");
                        setVisible(false);
                        Locale currentLocale = Locale.ENGLISH;
                        new MainScreen(pin,currentLocale);
                    }
                }
            }
            else {
                setVisible(false);
                Locale currentLocale = Locale.ENGLISH;
                new MainScreen(pin,currentLocale);
            }

        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new withdrawal("");
    }
}
