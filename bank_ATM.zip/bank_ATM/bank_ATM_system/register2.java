package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class register2 extends JFrame implements ActionListener {
    JComboBox comboBox1,comboBox2,comboBox3,comboBox4,comboBox5;
    JTextField textpan,adhrno;
    JRadioButton r1,r2,r3,r4;
    JButton next;
    String formNo;
    register2(String form_no){
        super ("APPLICATION FORM 2");

        this.formNo = form_no;
        setTitle("Banking System - Account Creation");
        setSize(870, 800);  // Set window size to 1000x900
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // Using absolute layout for custom positioning

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(25, 10, 100, 100);
        add(image);

        JLabel label1 = new JLabel("APPLICATION FORM NO. "+form_no);
        label1.setBounds(190,20,600,40);
        label1.setFont(new Font("Rale way",Font.BOLD,38));
        add(label1);

        JLabel label2 = new JLabel("Page 2");
        label2.setBounds(300,90,600,30);
        label2.setFont(new Font("Rale way",Font.BOLD,22));
        add(label2);

        JLabel label3 = new JLabel("Additional Details");
        label3.setBounds(300,120,600,30);
        label3.setFont(new Font("Rale way",Font.BOLD,22));
        add(label3);

        JLabel labelName = new JLabel("Religion ");
        labelName.setBounds(100,190,100,30);
        labelName.setFont(new Font("Rale way",Font.BOLD,20));
        add(labelName);

        String[] religion = {"Hindu","Muslim","Sikh","Christianity","Jain","Jewish","Zoroastrain","Other"};
        comboBox1 = new JComboBox(religion);
        comboBox1.setBackground(new Color(239, 239, 239));
        comboBox1.setFont(new Font("Rale way",Font.BOLD,14));
        comboBox1.setBounds(300,190,400,30);
        add(comboBox1);

        JLabel labelfName = new JLabel("Category ");
        labelfName.setBounds(100,240,300,30);
        labelfName.setFont(new Font("Rale way",Font.BOLD,20));
        add(labelfName);

        String[] Category = {"General","OBC","ST","SC","Other"};
        comboBox2 = new JComboBox(Category);
        comboBox2.setBackground(new Color(239, 239, 239));
        comboBox2.setFont(new Font("Rale way",Font.BOLD,14));
        comboBox2.setBounds(300,240,400,30);
        add(comboBox2);

        JLabel income = new JLabel("Income ");
        income.setBounds(100,290,200,30);
        income.setFont(new Font("Rale way",Font.BOLD,20));
        add(income);

        String[] incomeLvl = {"Null","<2,50,000","<5,00,00","Upto 10,00,00","Above 10,00,000"};
        comboBox3 = new JComboBox(incomeLvl);
        comboBox3.setBackground(new Color(239, 239, 239));
        comboBox3.setFont(new Font("Rale way",Font.BOLD,14));
        comboBox3.setBounds(300,290,400,30);
        add(comboBox3);

        JLabel edu = new JLabel("Education ");
        edu.setBounds(100,340,200,30);
        edu.setFont(new Font("Rale way",Font.BOLD,20));
        add(edu);

        String[] education = {"Non-Graduate","Graduate","Post-Graduate","Doctrate","Others"};
        comboBox4 = new JComboBox(education);
        comboBox4.setBackground(new Color(239, 239, 239));
        comboBox4.setFont(new Font("Rale way",Font.BOLD,14));
        comboBox4.setBounds(300,340,400,30);
        add(comboBox4);

        JLabel ocu = new JLabel("Occupation ");
        ocu.setFont(new Font("Rale way",Font.BOLD,20));
        ocu.setBounds(100,390,200,30);
        add(ocu);

        String[] occupation = {"Salaried","Self-Employed","Business","Student","Retired","Other"};
        comboBox5 = new JComboBox(occupation);
        comboBox5.setBackground(new Color(239, 239, 239));
        comboBox5.setFont(new Font("Rale way",Font.BOLD,14));
        comboBox5.setBounds(300,390,400,30);
        add(comboBox5);

        JLabel pan = new JLabel("PAN Number ");
        pan.setFont(new Font("Rale way",Font.BOLD,20));
        pan.setBounds(100,440,400,30);
        add(pan);

        textpan = new JTextField();
        textpan.setFont(new Font("Rale way",Font.BOLD,20));
        textpan.setBounds(300,440,400,30);
        add(textpan);

        JLabel adhr = new JLabel("Aadhar Number ");
        adhr.setFont(new Font("Rale way",Font.BOLD,20));
        adhr.setBounds(100,490,400,30);
        add(adhr);

        adhrno = new JTextField();
        adhrno.setFont(new Font("Rale way",Font.BOLD,20));
        adhrno.setBounds(300,490,400,30);
        add(adhrno);

        JLabel srcitizen = new JLabel("Senior Citizen ");
        srcitizen.setFont(new Font("Rale way",Font.BOLD,20));
        srcitizen.setBounds(100,540,400,30);
        add(srcitizen);

        r1 = new JRadioButton("YES");
        r1.setFont(new Font("Rale way",Font.BOLD,14));
        r1.setBounds(300,540,80,30);
        add(r1);

        r2 = new JRadioButton("NO");
        r2.setFont(new Font("Rale way",Font.BOLD,14));
        r2.setBounds(400,540,80,30);
        add(r2);

        ButtonGroup btngrp = new ButtonGroup();
        btngrp.add(r1);
        btngrp.add(r2);

        JLabel exac = new JLabel("Existing Account ");
        exac.setFont(new Font("Rale way",Font.BOLD,20));
        exac.setBounds(100,590,400,30);
        add(exac);

        r3 = new JRadioButton("YES");
        r3.setFont(new Font("Rale way",Font.BOLD,14));
        r3.setBounds(300,590,80,30);
        add(r3);

        r4 = new JRadioButton("NO");
        r4.setFont(new Font("Rale way",Font.BOLD,14));
        r4.setBounds(400,590,80,30);
        add(r4);

        ButtonGroup btngrp2= new ButtonGroup();
        btngrp2.add(r3);
        btngrp2.add(r4);

        next = new JButton("Next");
        next.setFont(new Font("Rale way",Font.BOLD,14));
        next.setBackground(Color.BLACK);
        next.setForeground(Color.white);
        next.setBounds(620,660,80,30);
        next.addActionListener(this);
        add(next);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/bank.png")));
        setIconImage(logo.getImage());

        setVisible(true);
        setLocation(370,10);
        getContentPane().setBackground(new Color(207, 207, 207));

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String rel = (String) comboBox1.getSelectedItem();
        String cat = (String) comboBox2.getSelectedItem();
        String income = (String) comboBox3.getSelectedItem();
        String edu = (String) comboBox4.getSelectedItem();
        String occ = (String) comboBox5.getSelectedItem();
        String PAN = textpan.getText();
        String aadhar = adhrno.getText();
        String scitizen = null;
        if (r1.isSelected()) {
            scitizen = "YES";
        }else if (r2.isSelected()){
            scitizen = "NO";
        }
        String exaccount = null;
        if (r3.isSelected()){
            exaccount = "YES";
        } else if (r3.isSelected()) {
            exaccount = "NO";
        }
        try{
            if (textpan.getText().isEmpty() || adhrno.getText().isEmpty()){
                JOptionPane.showMessageDialog(null,"Please fill all the fields");
            }else {
                Conn conn8 = new Conn();
                conn8.ConnectMain();
                conn8.insert_into_register2(this.formNo,rel,cat,income,edu,occ,PAN,aadhar,scitizen,exaccount);
                new register3(this.formNo);
                setVisible(false);
            }
        }catch (Exception E){
            E.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new register2("");
    }
}
