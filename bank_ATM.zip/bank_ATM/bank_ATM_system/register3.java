package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.Random;

public class register3 extends JFrame implements ActionListener {
    JRadioButton r1,r2,r3,r4;
    JCheckBox c1,c2,c3,c4,c5,c6;
    JButton submit,cancel;
    String form_NO;

    register3(String form_no){
        super ("APPLICATION FORM 3");
        this.form_NO = form_no;

        setTitle("Banking System - Account Creation");
        setSize(750, 850);  // Set window size to 1000x900
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // Using absolute layout for custom positioning

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(25, 10, 100, 100);
        add(image);

        JLabel label1 = new JLabel("FORM NO. "+this.form_NO);
        label1.setBounds(190,20,600,40);
        label1.setFont(new Font("Rale way",Font.BOLD,38));
        add(label1);

        JLabel label2 = new JLabel("Page 3");
        label2.setBounds(190,90,600,30);
        label2.setFont(new Font("Rale way",Font.BOLD,22));
        add(label2);

        JLabel label3 = new JLabel("Account Details");
        label3.setBounds(190,120,600,30);
        label3.setFont(new Font("Rale way",Font.BOLD,22));
        add(label3);

        JLabel label4 = new JLabel("Account Type: ");
        label4.setBounds(100,180,600,30);
        label4.setFont(new Font("Rale way",Font.BOLD,22));
        add(label4);

        r1 = new JRadioButton("Saving Account");
        r1.setFont(new Font("Rale way",Font.BOLD,14));
        r1.setBounds(100,230,215,30);
        add(r1);

        r2 = new JRadioButton("Current Account");
        r2.setFont(new Font("Rale way",Font.BOLD,14));
        r2.setBounds(400,230,215,30);
        add(r2);

        r3 = new JRadioButton("Recurring Deposit Account");
        r3.setFont(new Font("Rale way",Font.BOLD,14));
        r3.setBounds(100,280,215,30);
        add(r3);

        r4 = new JRadioButton("Fixed Deposit Account");
        r4.setFont(new Font("Rale way",Font.BOLD,14));
        r4.setBounds(400,280,215,30);
        add(r4);

        ButtonGroup btngrp = new ButtonGroup();
        btngrp.add(r1);
        btngrp.add(r2);
        btngrp.add(r3);
        btngrp.add(r4);

        JLabel label5 = new JLabel("Card Number: ");
        label5.setBounds(100,340,600,30);
        label5.setFont(new Font("Rale way",Font.BOLD,22));
        add(label5);

        JLabel label6 = new JLabel("(Your 16-digit Card Number) ");
        label6.setBounds(100,370,600,30);
        label6.setFont(new Font("Rale way",Font.BOLD,12));
        add(label6);

        JLabel label7 = new JLabel("XXXX-XXXX-XXXX-8482 ");
        label7.setBounds(300,340,600,30);
        label7.setFont(new Font("Rale way",Font.BOLD,22));
        add(label7);

        JLabel label8 = new JLabel("(It would appear on atm card/cheque Book and Statements) ");
        label8.setBounds(300,370,600,30);
        label8.setFont(new Font("Rale way",Font.BOLD,12));
        add(label8);

        JLabel label9 = new JLabel("PIN: ");
        label9.setBounds(100,420,600,30);
        label9.setFont(new Font("Rale way",Font.BOLD,22));
        add(label9);

        JLabel label11 = new JLabel("(Your 4-digit PIN Number) ");
        label11.setBounds(100,450,600,30);
        label11.setFont(new Font("Rale way",Font.BOLD,12));
        add(label11);

        JLabel label10 = new JLabel("XXXX ");
        label10.setBounds(300,420,600,30);
        label10.setFont(new Font("Rale way",Font.BOLD,22));
        add(label10);

        JLabel label12 = new JLabel("(Alloted By Bank Itself) ");
        label12.setBounds(300,450,600,30);
        label12.setFont(new Font("Rale way",Font.BOLD,12));
        add(label12);

        JLabel label13 = new JLabel("Services Required: ");
        label13.setBounds(100,500,600,30);
        label13.setFont(new Font("Rale way",Font.BOLD,22));
        add(label13);

        c1 = new JCheckBox("ATM Card");
        c1.setBackground(new Color(239,239,239));
        c1.setFont(new Font("Rale way",Font.BOLD,16));
        c1.setBounds(100,550,200,30);
        add(c1);

        c2 = new JCheckBox("Internet Banking");
        c2.setBackground(new Color(239,239,239));
        c2.setFont(new Font("Rale way",Font.BOLD,16));
        c2.setBounds(100,600,200,30);
        add(c2);

        c3 = new JCheckBox("Mobile Banking");
        c3.setBackground(new Color(239,239,239));
        c3.setFont(new Font("Rale way",Font.BOLD,16));
        c3.setBounds(100,650,200,30);
        add(c3);

        c4 = new JCheckBox("EMAIL Alerts");
        c4.setBackground(new Color(239,239,239));
        c4.setFont(new Font("Rale way",Font.BOLD,16));
        c4.setBounds(400,550,200,30);
        add(c4);

        c5 = new JCheckBox("Cheque Book");
        c5.setBackground(new Color(239,239,239));
        c5.setFont(new Font("Rale way",Font.BOLD,16));
        c5.setBounds(400,600,200,30);
        add(c5);

        c6 = new JCheckBox("E-Statement");
        c6.setBackground(new Color(239,239,239));
        c6.setFont(new Font("Rale way",Font.BOLD,16));
        c6.setBounds(400,650,200,30);
        add(c6);

        JCheckBox c7 = new JCheckBox(
                "I hereby declares that the above entered details are correct to the best of my knowledge.",true);
        c7.setBackground(new Color(207,207,207));
        c7.setFont(new Font("Rale way",Font.BOLD,13));
        c7.setBounds(100,700,600,30);
        add(c7);

        submit = new JButton("Submit");
        submit.setFont(new Font("Rale way",Font.BOLD,14));
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.white);
        submit.setBounds(100,750,110,30);
        submit.addActionListener(this);
        add(submit);

        cancel = new JButton("Cancel");
        cancel.setFont(new Font("Rale way",Font.BOLD,14));
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.white);
        cancel.setBounds(250,750,110,30);
        cancel.addActionListener(this);
        add(cancel);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/bank.png")));
        setIconImage(logo.getImage());

        setVisible(true);
        setLocation(370,10);
        getContentPane().setBackground(new Color(207, 207, 207));
    }

    public String PIN_hashing(String pin) throws NoSuchAlgorithmException {
        MessageDigest msgDigest = MessageDigest.getInstance("MD5");
        msgDigest.update(pin.getBytes(StandardCharsets.UTF_8));
        byte[] result = msgDigest.digest();

        StringBuilder sb = new StringBuilder();

        for (byte b : result){
            sb.append(String.format("%02x",b));
        }
        return sb.toString();
    }

    public boolean verifyPIN(String inputPIN, String storedHash) {
        try {
            String hashedInput = PIN_hashing(inputPIN);
            return hashedInput.equals(storedHash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String acType = null;
        if (r1.isSelected()){
            acType = "Saving Account";
        } else if (r2.isSelected()) {
            acType = "Current Account";
        } else if (r3.isSelected()) {
            acType = "Recurring Deposit Account";
        } else if (r4.isSelected()){
            acType = "Fixed Deposit Account";
        }

        Random ran = new Random();
        long first7 = (ran.nextLong() % 90000000L) + 1409963000000000L;
        String cardNO = ""+Math.abs(first7);

        long first3 = (ran.nextLong() % 9000L) + 1000L;
        String pin = ""+Math.abs(first3);

        String fac = "";
        if (c1.isSelected()){
            fac += "ATM CARD ";
        } else if (c2.isSelected()) {
            fac += "Internet Banking ";
        } else if (c3.isSelected()) {
            fac += "Mobile Banking ";
        } else if (c4.isSelected()) {
            fac += "EMAIL Alerts ";
        } else if (c5.isSelected()) {
            fac += "Cheque Book ";
        } else if (c6.isSelected()) {
            fac += "E-Statement ";
        }

        System.out.println(acType);
        System.out.println(cardNO);
        System.out.println(pin);
        System.out.println(fac );

        try {
            if (e.getSource() == submit){
                String HashedPIN = PIN_hashing(pin);
                if (acType == null){
                    JOptionPane.showMessageDialog(null,"Fill all the Fields ");
                }else {
                    Conn conn9 = new Conn();
                    conn9.ConnectMain();
                    conn9.insert_into_register3(this.form_NO,acType,cardNO,HashedPIN,fac);
                    conn9.loginInsert(cardNO,HashedPIN);
                    JOptionPane.showMessageDialog(null,"Card Number : "+cardNO + "\nPIN : "+pin);
                    new Deposit(HashedPIN);
                    setVisible(false);
                }
            } else if (e.getSource() == cancel) {
                System.exit(0);
            }
        }catch (Exception E){
            E.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new register3("");
    }
}
