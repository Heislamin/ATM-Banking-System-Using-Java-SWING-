package bank_ATM_system;

import bank_ATM_system.Connection_to_database.Conn;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Objects;

public class PIN extends JFrame implements ActionListener {
    JButton b1,b2;
    JPasswordField p1,p2;
    String pin;
    PIN(String pin){
        this.pin = pin;

        ImageIcon bg = new ImageIcon(ClassLoader.getSystemResource("icon/atm2.png"));
        Image bg2 = bg.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon bg3 = new ImageIcon(bg2);
        JLabel l1 = new JLabel(bg3);
        l1.setBounds(-40,0,1550,830);
        add(l1);

        JLabel label1 = new JLabel(("CHANGE YOUR PIN"));
        label1.setForeground(Color.white);
        label1.setFont(new Font("System",Font.BOLD,16));
        label1.setBounds(560,180,400,35);
        l1.add(label1);

        JLabel label2 = new JLabel(("NEW PIN"));
        label2.setForeground(Color.white);
        label2.setFont(new Font("System",Font.BOLD,16));
        label2.setBounds(435,267,400,35);
        l1.add(label2);

        p1 = new JPasswordField();
        p1.setBackground(new Color(65,125,128));
        p1.setForeground(Color.WHITE);
        p1.setBounds(530,267,250,35);
        p1.setFont(new Font("Railway",Font.BOLD,22));
        l1.add(p1);
        AbstractDocument document1 = (AbstractDocument) p1.getDocument();
        document1.setDocumentFilter(new DoubleDocumentFilter());

        b1 = new JButton("CHANGE");
        b1.setBounds(410,365,150,35);
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.white);
        b1.addActionListener(this);
        l1.add(b1);

        b2 = new JButton("BACK");
        b2.setBounds(410,409,150,35);
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.white);
        b2.addActionListener(this);
        l1.add(b2);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(getClass().getClassLoader().getResource("icon/ATMlogo.png")));
        setIconImage(logo.getImage());

        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocation(0,0);
        setVisible(true);

    }

    public String PIN_hashing(String pin) throws NoSuchAlgorithmException {
        MessageDigest msgDigest = MessageDigest.getInstance("MD5");
        msgDigest.update(pin.getBytes(StandardCharsets.UTF_8));
        byte[] result = msgDigest.digest();

        StringBuilder sb = new StringBuilder();

        for (byte b : result){
            sb.append(String.format("%02x",b));
        }
        return sb.toString();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1){
            String newPin = new String(p1.getPassword());
            try {
                String HashedNewPin = PIN_hashing(newPin);
                String PIN = this.pin;
                Conn conn6 = new Conn();
                conn6.ConnectMain();
//                System.out.println("a : " + PIN + " b : " + this.pin + "c : " + newPin.toString());
                conn6.Pin_Update(this.pin,HashedNewPin);
                JOptionPane.showMessageDialog(null, "PIN updated Successfully");
                setVisible(false);
                JOptionPane.showMessageDialog(null,"Please Relogin with new PIN!");
                System.exit(0);
            } catch (NoSuchAlgorithmException | SQLException ex) {
                throw new RuntimeException(ex);
            }
        }else {
            Locale currentLocale = Locale.ENGLISH;
            new MainScreen(this.pin,currentLocale);
        }

    }

    public static void main(String[] args) {
        new PIN("");
    }
}
